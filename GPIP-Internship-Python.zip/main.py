import json
from datetime import datetime
import time 

class Trace:
    eventID = ''
    timestamp = ''
    eventletter = ''


def inputData(filename, events):
    print('Reading {}'.format(filename))
    try:
        file = open(filename, 'r')
    except:
        print('**Error: unable to open {}'.format(filename))
        return False
    traces = []
    firstSkipped = False
    count = 0
    oldid = None
    for line in file:
        if firstSkipped:
            count += 1
            line = line[:-1] if line[-1] == '\n' else line
            items = line.split(',')
            trace = Trace()
            trace.eventID = items[0]
            trace.eventletter = items[1]
            trace.timestamp = items[2]
            if count == 1:
                oldid = trace.eventID

            if oldid == trace.eventID:
                traces.append(trace)

            else:
                oldid = trace.eventID
                events.append(traces)
                traces = []
                traces.append(trace)
        else:
            firstSkipped = True

    events.append(traces)
    file.close()
    return True


def eventstats(events):
    cases = {}
    
    timestamp = {}
    for k in range(0, len(events)):
        #cases.append(events[k][0].eventID)
        count = 0
        first = datetime.strptime(events[k][0].timestamp, "%Y-%m-%d %H:%M:%S")
        for i in range(0, len(events[k])):
            count = count + 1
            
        cases[events[k][0].eventID] = count
        last = datetime.strptime(events[k][count-1].timestamp, "%Y-%m-%d %H:%M:%S")
        totaltimesec = last-first
        timestamp[events[k][0].eventID] = totaltimesec
    output = '[\n'
    i = 1
    for lines in cases.keys():
        str = '{'
        str += '"case": {}, "numEvents": {}, "duration": {}'.format(lines, cases[lines], timestamp[lines])
        if i < len(cases.keys()):
            str += '},\n'
        else:
            str += '}\n'
        output += str
        i = i + 1
    output += ']'
    file = open('eventstats.txt', 'w')
    file.write(output)
    file.close()


def eventsname(events):
    lines2 = []
    for k in range(0, len(events)):
        for i in range(0, len(events[k])):
            if len(lines2) == 0:
                lines2.append(events[k][i].eventletter)
            if events[k][i].eventletter not in lines2:
                lines2.append(events[k][i].eventletter)

    file = open('eventsname.txt', 'w')
    for x in lines2:
        file.writelines('{}\n'.format(x))
    file.close()


def presuf(events):
    lines = []
    for i in range(0, len(events)):
        lines.append('Case: {}\n'.format(events[i][0].eventID))
        count = 1
        for k in range(0, len(events[i]) - 1):
            lines.append(str(k + 1))
            lines.append(' Prefix: ')
            for m in range(0, count):
                lines.append('{} '.format(events[i][m].eventletter))

            count = count + 1
            lines.append('\n')
            lines.append(str(k + 1))
            lines.append(' Suffix: ')

            for q in range((k + 1), len(events[i]), 1):
                lines.append('{} '.format(events[i][q].eventletter))
            lines.append('\n')
            lines.append('\n')

    file = open('prefixsuffix.txt', 'w')
    file.writelines(lines)
    file.close()


def variants(events):
    variants = {}
    for i in range(0, len(events)):
        lines = ''
        for k in range(0, len(events[i])):
            lines += events[i][k].eventletter

        if lines not in variants.keys():
            variants[lines] = 1
        else:
            variants[lines] += 1

    i = 1
    output = '[\n'
    for lines in variants.keys():
        str = '{'
        str += '"variants": {}, "frequency": {}'.format(lines, variants[lines])
        if i < len(variants.keys()):
            str += '},\n'
        else:
            str += '}\n'
        i = i + 1
        output += str
    output += ']'
    file = open('variants.txt', 'w')
    file.write(output)
    file.close()

def main():
    events = []
    success = inputData('eventlog.csv', events)
    if not success:
        print('No data, file not found?')
        return 0
    print('Number of events: {}'.format(len(events)))
    variants(events)
    #presuf(events)
    eventstats(events)
    #eventsname(events)


main()
